#include "member.h"
#include <iostream>

using namespace std;

int main()
{
    member M;

    inputData_nim(M);
    showData_nim(M);

    cout << "Dengan rata-rata Poin: " << ratarata_nim(M) << endl;
    return 0;
}
