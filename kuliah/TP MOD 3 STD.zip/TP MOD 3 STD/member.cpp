#include "member.h"
#include <iostream>

using namespace std;

void inputData_nim(member &MB) {

    int k;

    cout << "Tuliskan IDNumber : ";
    cin >> MB.IDNumber;

    k = 0;

    while(k < Max) {
        cout << "Poin bulen ke-" << k+1 << ": ";
        cin >> MB.Poin[k];

        k++;
    }

}

float ratarata_nim(member MB) {

    float poin = 0;
    int k = 0;

    while (k < Max) {
        poin += MB.Poin[k];
        k++;
    }

    return poin/Max;

}

void showData_nim(member MB) {

    cout << "Data Member: " << endl;
    cout << "IDNumber: " << MB.IDNumber << endl;
    cout << "Poin: ";

    for (int i = 0;i < Max;i++) {
        cout << MB.Poin[i] << " ";
    }

    cout << endl;

}
