#include <bits/stdc++.h>
using namespace std;
class SchoolAdmin: public User{
	public:
		string staffID,position;

		string getStaffID(){
			return staffID;
		}
		void setStaffID(string x){
			staffID = x;
		}
		string getPosition(){
			return position;
		}
		void setPosition(string x){
			position = x;
		}
};

