#include <bits/stdc++.h>
#include "User.cpp"
#include "School.cpp"
#include "SchoolAdmin.cpp"
#include "SchoolHelp.cpp"
using namespace std;

bool isLogin = false;
int typeLogin=0;
SchoolHelp sh;
vector<SchoolAdmin> listSchoolAdmin;

//school
void registerSchool(vector<School> &listSchool){
	int itmp;string stmp;
	School s;
	cout << "School Name : ";cin  >> stmp;
	s.setSchoolName(stmp);
	cout << "Address : ";cin >> stmp;
	s.setAddress(stmp);
	cout << "City : ";cin >> stmp;
	s.setCity(stmp);
	itmp = rand();
	s.setSchoolID(itmp);
	listSchool.push_back(s);
	cout << "Data successful added" << endl << endl;
}
void showSchool(vector<School> listSchool){
	cout << "=== List School ===" << endl;
	int i=1;
	for(auto x:listSchool){
		cout << "No : "<< i << endl;
		cout << "School ID : " << x.getSchoolID() << endl;
		cout << "School Name : " << x.getSchoolName() << endl;
		cout << "Address : " << x.getAddress() << endl;
		cout << "City : " << x.getCity() << endl;
		cout << endl;
		i++;
	}
}
//end school

//school admin

void registerSchoolAdmin(vector<SchoolAdmin> &listSchoolAdmin){
	SchoolAdmin data;
	string tmp;
	cout << "Username : ";cin >> tmp;
	data.setUsername(tmp);
	cout << "Password : ";cin >> tmp;
	data.setPassword(tmp);
	cout << "Fullname : ";cin >> tmp;
	data.setFullname(tmp);
	cout << "Email : ";cin >> tmp;
	data.setEmail(tmp);
	cout << "Phone : ";cin >> tmp;
	data.setPhone(tmp);
	cout << "Staff ID : ";cin >> tmp;
	data.setStaffID(tmp);
	cout << "Position : ";cin >> tmp;
	data.setPosition(tmp);
	listSchoolAdmin.push_back(data);
	cout << "Data succesful added" << endl << endl;
}
void showSchoolAdmin(vector<SchoolAdmin> listSchoolAdmin){
	cout << "=== List School Admin ===" << endl;
	int i=1;
	for(auto x:listSchoolAdmin){
		cout << "No : "<< i << endl;
		cout << "Username : " << x.getUsername() << endl;
		cout << "Password : " << x.getPassword() << endl;
		cout << "Fullname : " << x.getFullname() << endl;
		cout << "Email : " << x.getEmail() << endl;
		cout << "Phone : " << x.getPhone() << endl;
		cout << "Staff ID : " << x.getStaffID() << endl;
		cout << "Position : " << x.getPosition() << endl << endl;
		i++;
	}
}
//end-school admin

//login admin help
void login(){
	string username,password;
	while(isLogin==false){
		cout << "=== SchoolHelp System ===" << endl;
		cout << "Username : ";cin >> username;
		cout << "Password : ";cin >> password;
		if(username==sh.username && password == sh.password){
			cout << "Login successful" << endl;
			cout << endl;
			isLogin=true;
			typeLogin =1;
		}else{
			cout << "Login failed" << endl;
			cout << endl;
		}

	}
}

void loginSchoolAdmin(){
	string username,password;
	while(isLogin==false){
		cout << "=== SchoolHelp System ===" << endl;
		cout << "Username : ";cin >> username;
		cout << "Password : ";cin >> password;
		bool ans=false;
		SchoolAdmin tmp;
		for(auto x:listSchoolAdmin){
			if(x.getUsername() == username){
				ans=true;
				tmp = x;
				break;
			}
		}
		if(ans){
			if(username==tmp.username && password == tmp.password){
				cout << "Login successful" << endl;
				cout << endl;
				isLogin=true;
				typeLogin =2;
			}else{
				cout << "Wrong password" << endl;
				cout << endl;
			}
		}else{
			cout << "Username not found" << endl;
			cout << endl;
		}

	}
}

void loginMain(){
	int l=1;
	while (l!=0 && isLogin==false) {	
		cout << "=== SchoolHelp System ===" << endl;
		cout << "1.Login as SchoolHelp Admin" << endl;
		cout << "2.Login as School Administrator" << endl;
		cout << "your option : ";cin >> l;
		if(l==1){
			login();
		}else if(l==2) {
			loginSchoolAdmin();	
		}
	}

}
int main(){
	int x=1;
	
	vector<School> listSchool;
	loginMain();
	while (isLogin) {
		if (typeLogin == 1) {
			cout << "=== SchoolHelp System ===" << endl;
			cout << "1.Register School" << endl;
			cout << "2.School Data" << endl;
			cout << "3.Register School Administrator" << endl;
			cout << "4.School Administrator Data" << endl;
			cout << "0.logout" << endl;
			cout << "your option : ";cin >> x;

			//statement
			if(x==1){
				registerSchool(listSchool);
			}else if (x==2) {
				showSchool(listSchool);
			}else if(x==3){
				registerSchoolAdmin(listSchoolAdmin);
			}else if (x==4) {
				showSchoolAdmin(listSchoolAdmin);
			}else if (x==0) {
				isLogin=false;
				loginMain();
			}
		}else if(typeLogin == 2){
			cout << "=== SchoolHelp System ===" << endl;
			cout << "1.Change Profile" << endl;
			cout << "0.logout" << endl;
			cout << "your option : ";cin >> x;

			//statement
			if(x==1){
				cout << "Soon" << endl;
			}else if (x==0) {
				isLogin=false;
				loginMain();
			}

		}
	}

}

