#include <bits/stdc++.h>
using namespace std;
class SchoolHelp : public User{
	public:
		SchoolHelp(){
			username = "meiska";
			password = "meiskaa";
		}
	};

